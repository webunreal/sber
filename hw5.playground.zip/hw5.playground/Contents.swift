import UIKit

// Direct Dispatch
// Самый быстрый. Отсутствуют наследование и полиморфизм.
// Ключевое слово final для классов и их методов позволяет использовать Direct Dispatch.

struct DirectDispatchStruct {
    let directDispatchFirstVariable: Int
    let directDispatchSecondVariable: Int
    
    func multiply() -> Int {
        directDispatchFirstVariable * directDispatchSecondVariable
    }
}

let directDispatchStruct = DirectDispatchStruct(directDispatchFirstVariable: 1, directDispatchSecondVariable: 2)
let directDispatchMultiplication = directDispatchStruct.multiply()

// Класс и расширение
class DirectDispatchClass {}

extension DirectDispatchClass {
    func doSomething() {}
}

// NSObject
class DirectDispatchNSObjectClass: NSObject {}

extension DirectDispatchNSObjectClass {
    func doSomething() {}
}

// Witness Table
// Медленнее, чем Direct Dispatch. Отсутствует наследование, реализует полиморфизм.

protocol Multiplicatable {
    func multiply() -> Int
}

struct WitnessTableStruct: Multiplicatable {
    let witnessTableFirstVariable: Int
    let witnessTableSecondVariable: Int
    
    func multiply() -> Int {
        witnessTableFirstVariable * witnessTableSecondVariable
    }
}

let witnessTableStruct = WitnessTableStruct(witnessTableFirstVariable: 1, witnessTableSecondVariable: 2)
let witnessTableMultiplication = witnessTableStruct.multiply() // Здесь будет Direct Dispatch

let witnessTableTrueStruct: Multiplicatable = WitnessTableStruct(witnessTableFirstVariable: 2, witnessTableSecondVariable: 3)
let witnessTableTrueMultipliction = witnessTableTrueStruct.multiply() // А здесь уже Witness Table

// Класс и расширение
class SomeClass {}

protocol SomeDoable {
    func doSomething()
}

extension SomeClass: SomeDoable {
    func doSomething() {}
}



// Virtual Table
// Скорость та же, что и у Witness Table. Реализует наследование и полиморфизм. Требует дополнительных затрат при компиляции.

class VirtualTableClass {
    let virtualTableFirstVariable: Int
    let virtualTableSecondVariable: Int
    
    init(first: Int, second: Int) {
        virtualTableFirstVariable = first
        virtualTableSecondVariable = second
    }
    
    func multiply() -> Int {
        virtualTableFirstVariable * virtualTableSecondVariable
    }
}

let virtualTableClass = VirtualTableClass(first: 1, second: 2)
let virtualTableClassMultipliction = virtualTableClass.multiply()


class AnotherVirtualTableClass: VirtualTableClass {
    let times: Int
    
    init(first: Int, second: Int, times: Int) {
        self.times = times
        super.init(first: first, second: second)
    }
    
    override func multiply() -> Int {
        virtualTableFirstVariable * virtualTableSecondVariable * times
    }
}

let anotherVirtualTableClass: VirtualTableClass = AnotherVirtualTableClass(first: 1, second: 2, times: 0)
let anotherVirtualTableClassMultipliction = anotherVirtualTableClass.multiply()


// NSObject
class NSObjectClass: NSObject {
    let nSObjectClassFirstVariable: Int
    let nSObjectClassSecondVariable: Int
    
    init(first: Int, second: Int) {
        nSObjectClassFirstVariable = first
        nSObjectClassSecondVariable = second
    }
    
    func multiply() -> Int {
        nSObjectClassFirstVariable * nSObjectClassSecondVariable
    }
}

let nSObjectClass = NSObjectClass(first: 1, second: 2)
let nSObjectClassMultipliction = nSObjectClass.multiply()




// Message Dispatch
// Самый медленный. Нет смещений, все происходит в runtime.

class MessageDispatchClass: NSObject {
    @objc dynamic var messageDispatchFirstVariable: Int
    @objc dynamic var messageDispatchSecondVariable: Int
    
    @objc dynamic init(first: Int, second: Int) {
        messageDispatchFirstVariable = first
        messageDispatchSecondVariable = second
    }
    
    @objc dynamic func multiply() -> NSNumber {
        NSNumber(integerLiteral: messageDispatchFirstVariable * messageDispatchSecondVariable)
    }
}

let messageDispatchClass = MessageDispatchClass(first: 1, second: 2)
let messageDispatchClassMultipliction = messageDispatchClass.multiply()

// Расширение
class AnotherMessageDispatchClass: NSObject {}

extension AnotherMessageDispatchClass {
    @objc func doSomething() {}
}
